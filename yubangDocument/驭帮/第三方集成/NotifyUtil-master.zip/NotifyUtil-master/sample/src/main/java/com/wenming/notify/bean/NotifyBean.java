package com.wenming.notify.bean;

/**
 * Created by wenmingvs on 2016/1/22.
 */
public class NotifyBean {
    int imageId;
    int titleId;
    int typeId;

    public int getImageId() {
        return imageId;
    }

    public void setImageId(int imageId) {
        this.imageId = imageId;
    }

    public int getTitleId() {
        return titleId;
    }

    public void setTitleId(int titleId) {
        this.titleId = titleId;
    }

    public int getTypeId() {
        return typeId;
    }

    public void setTypeId(int typeId) {
        this.typeId = typeId;
    }
}
