package com.mingle.widget;

import android.view.MotionEvent;

/**
 * @author zzz40500
 * @version 1.0
 * @date 2015/8/8.
 * @github: https://github.com/zzz40500
 *
 */
public interface GrowUpParent {
    boolean onParentHandMotionEvent(MotionEvent event);
}
