package cn.sharesdk.share.demo.apshare;

import cn.sharesdk.alipay.share.AlipayHandlerActivity;

public class ShareEntryActivity extends AlipayHandlerActivity{

}
