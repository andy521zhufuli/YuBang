SMSSDK for Android
==================

Welcome to SMSSDK for Android Sample Project.

With SMSSDK ,your app can securely and quickly register new users 
with a SMS verification code sent to their Mobile phone.


Getting up
----------
We offer two popular IDE guide to integrate SMSSDK

###Android Studio

just clone down and open with Studio

###Eclipse

just clone down and import Project directory to Eclipse


Need more doc? please check at [Mob.com](http://www.mob.com) (Chinese)
