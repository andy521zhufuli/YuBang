package com.activities;

 
import com.adapters.PagerAdapter;
import com.adapters.ScrollTabsAdapter;
import com.adapters.TabAdapter;
import com.fragments.MyFragment;
 
 
import com.widgets.ScrollTabView;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;

import android.support.v4.view.ViewPager;

public class MainActivity extends FragmentActivity {

	private ScrollTabView scrollTabsView;
	private TabAdapter tabsAdapter;
	private ViewPager viewPager;
	private Context context;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		context=getBaseContext();
		
		initTabs();
		initViewPager();
	}
	
	
	void initTabs(){
		scrollTabsView= (ScrollTabView) findViewById(R.id.tabs);
		tabsAdapter=new ScrollTabsAdapter(this);
		
		tabsAdapter.add("���");
		tabsAdapter.add("����");
		tabsAdapter.add("������");
		tabsAdapter.add("ר��");
		tabsAdapter.add("�����б�");
		tabsAdapter.add("����");
		
		scrollTabsView.setAdapter(tabsAdapter);
	}
	
	void initViewPager(){
		viewPager=(ViewPager) findViewById(R.id.viewpager);
		
		PagerAdapter pagerAdapter=new PagerAdapter(
				getSupportFragmentManager());
		
		MyFragment f1=new MyFragment("���");
		pagerAdapter.addFragment(f1);
		
		MyFragment f2=new MyFragment("����");
		pagerAdapter.addFragment(f2);
		
		MyFragment f3=new MyFragment("������");
		pagerAdapter.addFragment(f3);
		
		MyFragment f4=new MyFragment("ר��");
		pagerAdapter.addFragment(f4);
		
		MyFragment f5=new MyFragment("�����б�");
		pagerAdapter.addFragment(f5);
		
		MyFragment f6=new MyFragment("����");
		pagerAdapter.addFragment(f6);
	
		viewPager.setAdapter(pagerAdapter);
		
		scrollTabsView.setViewPager(viewPager);
	}

}
