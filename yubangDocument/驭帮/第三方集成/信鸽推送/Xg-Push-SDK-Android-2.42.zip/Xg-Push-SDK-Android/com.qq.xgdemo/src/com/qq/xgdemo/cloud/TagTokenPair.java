package com.qq.xgdemo.cloud;

public class TagTokenPair {
    public TagTokenPair(String tag, String token)
    {
        this.tag = tag;
        this.token = token;
    }

    public String tag;
    public String token;
}