package com.tencent.sample.activitys;

import com.tencent.open.yyb.AppbarAgent;
import com.tencent.sample.R;
import com.tencent.tauth.Tencent;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

public class SocialAppbarActivity extends BaseActivity implements
		View.OnClickListener {
	private Tencent mTencent;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setBarTitle("应用吧");
		setLeftButtonEnable();

		setContentView(R.layout.social_appbar_layout);
		LinearLayout linearLayout = (LinearLayout) findViewById(R.id.main_container);
		for (int i = 0; i < linearLayout.getChildCount(); i++) {
			View view = linearLayout.getChildAt(i);
			if (view instanceof Button) {
				view.setOnClickListener(this);
			}
		}
		mTencent = Tencent.createInstance(MainActivity.mAppid, SocialAppbarActivity.this);
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
//		case R.id.appbarh5:
//			mTencent.startAppbarForceH5(this);
//			break;
		case R.id.appbar_detail:
			mTencent.startAppbar(this, AppbarAgent.TO_APPBAR_DETAIL);
			break;
		case R.id.appbar_my_message:
			mTencent.startAppbar(this, AppbarAgent.TO_APPBAR_NEWS);
			break;
		case R.id.appbar_send_blog:
			mTencent.startAppbar(this, AppbarAgent.TO_APPBAR_SEND_BLOG);
			break;
//		case R.id.appbar_detail_h5:
//			mTencent.startAppbar(this, AppbarAgent.TO_APPBAR_DETAIL, true);
//			break;
//		case R.id.appbar_my_message_h5:
//			mTencent.startAppbar(this, AppbarAgent.TO_APPBAR_NEWS, true);
//			break;
//		case R.id.appbar_send_blog_h5:
//			mTencent.startAppbar(this, AppbarAgent.TO_APPBAR_SEND_BLOG, true);
//			break;
		default:
			break;
		}
	}
}
